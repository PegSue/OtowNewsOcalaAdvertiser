<?php

include_once dirname(__FILE__)."/db_connect.php";
include_once dirname(__FILE__)."/functions.php";

sec_session_start(); // Our custom secure way of starting a PHP session.

if (isset($_POST['code'], $_POST['p'])) {
    $code = $_POST['code'];
    $password = $_POST['p']; // The hashed password.
    //echo 'Request Valid';
   
 //add check for advertiser email here also
    if (login($code, $password, $mysqli) == true) {
        // Login success 
        //echo 'login success';
         
      if ($code == 'EditorOcala') {
	header('Location: ../otownewsocala/editor_uploads.php');		
	} else {
	header('Location: ../otownewsocala/renewals.php');
	}
	
    } else {
        // Login failed 
      header('Location: ../otownewsocala/login.php?error=1');
    }
    
} else {
    // The correct POST variables were not sent to this page. 
    echo 'Invalid Request';
}

?>