﻿<?php
    echo phpinfo();
?>
