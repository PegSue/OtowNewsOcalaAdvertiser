<?php

include_once dirname(__FILE__)."/adv_essentials/db_connect.php";
include_once dirname(__FILE__)."/adv_essentials/functions.php";

sec_session_start();
 
if (login_check($mysqli) == true) {
    $logged = 'in';
} else {
    $logged = 'out';
}
?>

<!DOCTYPE html>

<html lang="en-US">

    <head>

        <meta charset="UTF-8" />

        <title>On Top of the World News Ocala</title>

        <meta name="description" content="Just another WordPress site" />

        <meta name="author" content="admin" />



        <link rel="pingback" href="http://ontopoftheworldnews.com/ocala/xmlrpc.php" />

        <!-- Mobile Specific Meta -->

        <link rel="shortcut icon" type="image/x-icon" href="http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/images/favicon.ico">
        <!-- Mobile Specific Meta -->

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />



        <link rel="alternate" type="application/rss+xml" title="On Top of the World News Ocala &raquo; Feed" href="http://ontopoftheworldnews.com/ocala/feed/" />
<link rel="alternate" type="application/rss+xml" title="On Top of the World News Ocala &raquo; Comments Feed" href="http://ontopoftheworldnews.com/ocala/comments/feed/" />
		<script type="text/javascript">
		    window._wpemojiSettings = { "baseUrl": "http:\/\/s.w.org\/images\/core\/emoji\/72x72\/", "ext": ".png", "source": { "concatemoji": "http:\/\/ontopoftheworldnews.com\/ocala\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.4" } };
		    !function (a, b, c) { function d(a) { var c = b.createElement("canvas"), d = c.getContext && c.getContext("2d"); return d && d.fillText ? (d.textBaseline = "top", d.font = "600 32px Arial", "flag" === a ? (d.fillText(String.fromCharCode(55356, 56812, 55356, 56807), 0, 0), c.toDataURL().length > 3e3) : (d.fillText(String.fromCharCode(55357, 56835), 0, 0), 0 !== d.getImageData(16, 16, 1, 1).data[0])) : !1 } function e(a) { var c = b.createElement("script"); c.src = a, c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c) } var f, g; c.supports = { simple: d("simple"), flag: d("flag") }, c.DOMReady = !1, c.readyCallback = function () { c.DOMReady = !0 }, c.supports.simple && c.supports.flag || (g = function () { c.readyCallback() }, b.addEventListener ? (b.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1)) : (a.attachEvent("onload", g), b.attachEvent("onreadystatechange", function () { "complete" === b.readyState && c.readyCallback() })), f = c.source || {}, f.concatemoji ? e(f.concatemoji) : f.wpemoji && f.twemoji && (e(f.twemoji), e(f.wpemoji))) }(window, document, window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://ontopoftheworldnews.com/ocala/wp-content/plugins/revslider/rs-plugin/css/settings.css?ver=4.6.93' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
.tp-caption a{color:#ff7302;text-shadow:none;-webkit-transition:all 0.2s ease-out;-moz-transition:all 0.2s ease-out;-o-transition:all 0.2s ease-out;-ms-transition:all 0.2s ease-out}.tp-caption a:hover{color:#ffa902}
</style>
<link rel='stylesheet' id='tt-base-font993126734-css'  href='http://fonts.googleapis.com/css?family=Enriqueta%3A400%2C700%7COpen+Sans%3A400italic%2C700italic%2C400%2C600%2C700&#038;ver=4.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='tt-bootstrap.css-css'  href='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/css/bootstrap.css?ver=4.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='tt-main-style-css'  href='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/css/style.css?ver=4.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='tt-theme-style-css'  href='http://ontopoftheworldnews.com/ocala/wp-content/themes/otownews/style.css?ver=4.3.4' type='text/css' media='all' />
<script type='text/javascript'>
    /* <![CDATA[ */
    var tesla_ajax = { "url": "http:\/\/ontopoftheworldnews.com\/ocala\/wp-admin\/admin-ajax.php", "nonce": "14cf467607" };
    tesla_ajax.actions = {
        electra_faq: {},
        electra_portfolio: {},
        electra_events: {},
        electra_gallery: {},
        electra_main: {},
        electra_services: {},
        electra_testimonials: {},
        electra_skills: {},
        electra_clients: {},
        electra_calendar: {},
        electra_toggle: {},
        electra_team: {},
        electra_price: {},
    };
    /* ]]> */
</script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-includes/js/jquery/jquery.js?ver=1.11.3'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.tools.min.js?ver=4.6.93'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/plugins/revslider/rs-plugin/js/jquery.themepunch.revolution.min.js?ver=4.6.93'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/tesla_framework/static/js/holder.js'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ontopoftheworldnews.com/ocala/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ontopoftheworldnews.com/ocala/wp-includes/wlwmanifest.xml" /> 

<link rel='canonical' href='http://ontopoftheworldnews.com/ocala/' />
<link rel='shortlink' href='http://ontopoftheworldnews.com/ocala/' />
		<script type="text/javascript">
		    jQuery(document).ready(function () {
		        // CUSTOM AJAX CONTENT LOADING FUNCTION
		        var ajaxRevslider = function (obj) {

		            // obj.type : Post Type
		            // obj.id : ID of Content to Load
		            // obj.aspectratio : The Aspect Ratio of the Container / Media
		            // obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content

		            var content = "";

		            data = {};

		            data.action = 'revslider_ajax_call_front';
		            data.client_action = 'get_slider_html';
		            data.token = 'ac924d4b73';
		            data.type = obj.type;
		            data.id = obj.id;
		            data.aspectratio = obj.aspectratio;

		            // SYNC AJAX REQUEST
		            jQuery.ajax({
		                type: "post",
		                url: "http://ontopoftheworldnews.com/ocala/wp-admin/admin-ajax.php",
		                dataType: 'json',
		                data: data,
		                async: false,
		                success: function (ret, textStatus, XMLHttpRequest) {
		                    if (ret.success == true)
		                        content = ret.data;
		                },
		                error: function (e) {
		                    console.log(e);
		                }
		            });

		            // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
		            return content;
		        };

		        // CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
		        var ajaxRemoveRevslider = function (obj) {
		            return jQuery(obj.selector + " .rev_slider").revkill();
		        };

		        // EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
		        var extendessential = setInterval(function () {
		            if (jQuery.fn.tpessential != undefined) {
		                clearInterval(extendessential);
		                if (typeof (jQuery.fn.tpessential.defaults) !== 'undefined') {
		                    jQuery.fn.tpessential.defaults.ajaxTypes.push({ type: "revslider", func: ajaxRevslider, killfunc: ajaxRemoveRevslider, openAnimationSpeed: 0.3 });
		                    // type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
		                    // func: the Function Name which is Called once the Item with the Post Type has been clicked
		                    // killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
		                    // openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
		                }
		            }
		        }, 30);
		    });
		</script>
		<script type="text/javascript">var ajaxurl = 'http://ontopoftheworldnews.com/ocala/wp-admin/admin-ajax.php';</script><script type="text/javascript">
		    (function (url) {
		        if (/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)) { return; }
		        var addEvent = function (evt, handler) {
		            if (window.addEventListener) {
		                document.addEventListener(evt, handler, false);
		            } else if (window.attachEvent) {
		                document.attachEvent('on' + evt, handler);
		            }
		        };
		        var removeEvent = function (evt, handler) {
		            if (window.removeEventListener) {
		                document.removeEventListener(evt, handler, false);
		            } else if (window.detachEvent) {
		                document.detachEvent('on' + evt, handler);
		            }
		        };
		        var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
		        var logHuman = function () {
		            var wfscr = document.createElement('script');
		            wfscr.type = 'text/javascript';
		            wfscr.async = true;
		            wfscr.src = url + '&r=' + Math.random();
		            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(wfscr);
		            for (var i = 0; i < evts.length; i++) {
		                removeEvent(evts[i], logHuman);
		            }
		        };
		        for (var i = 0; i < evts.length; i++) {
		            addEvent(evts[i], logHuman);
		        }
		    })('//ontopoftheworldnews.com/ocala/?wordfence_logHuman=1&hid=2FC41458920344672FABA4FD9B56A883');
</script><link rel="icon" href="http://ontopoftheworldnews.com/ocala/wp-content/uploads/2015/09/cropped-otow-32x32.jpg" sizes="32x32" />
<link rel="icon" href="http://ontopoftheworldnews.com/ocala/wp-content/uploads/2015/09/cropped-otow-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://ontopoftheworldnews.com/ocala/wp-content/uploads/2015/09/cropped-otow-180x180.jpg">
<meta name="msapplication-TileImage" content="http://ontopoftheworldnews.com/ocala/wp-content/uploads/2015/09/cropped-otow-270x270.jpg">
<style type="text/css">.electra_custom_background{background-position: top right;background-repeat: no-repeat;background-attachment: fixed;}
        a:hover {

            color: #22948f;

        }

        .color_scheme select:focus {

            border-color: #22948f;

        }

        .color_scheme li span.color_1 {

            background-color: #22948f;

        }

        .widget ul li a:hover {

            color: #22948f;

        }

        .attention_message h2 span {

            color: #22948f;

        }

        .boxed_fluid.black_version .blog_article .entry-header a:hover,

        .boxed_fluid.black_version .contect_bg .accordion_v2 .accordion-heading.active span {

            color: #22948f;

        }

        .header .menu ul li.current_page_item a,

        .header .menu ul li a:hover,

        .header .menu ul li:hover a {

            border-bottom-color: #22948f;

        }

        .header .menu ul li .children li .children li a:hover,

        .header .menu ul li .sub-menu li .sub-menu li a:hover,

        .header .menu ul li .children li:hover a,

        .header .menu ul li .sub-menu li:hover a,

        .header .menu ul li .children li a:hover, 

        .header .menu ul li .sub-menu li a:hover {

            color: #22948f;

        }

        .header .menu ul li .children li:hover .children,

        .header .menu ul li .sub-menu li:hover .sub-menu {

            border-top-color: #22948f;

        }

        .filter li a.active,

        .filter li a:hover {

            color: #22948f;

            border-bottom-color: #22948f;

        }

        .portfolio .portfolio_item .item_hover .item_tags li a {

            color: #22948f;

        }

        .tabs .tab_nav li.active a {

            border-top-color: 5px solid #22948f;

        }

        .tabs .tab-content .tab_title a:hover {

            color: #22948f;

        }

        .button_color {

            background-color: #22948f;

        }

        .error_404 .error_text span span {

            color: #22948f;

        }

        .pricing_table_2 .pt_button {

            background-color: #22948f;

        }

        .accordion-heading.active span {

            color: #22948f;

        }

        .skills .skill_cover .skill {

            background-color: #22948f;

        }

        .input_button {

            background-color: #22948f;

        }

        .page-numbers li a.active,

        .page-numbers li a:hover {

            color: #22948f;

            border-bottom-color: #22948f;

        }

        .share_it .socials_2 li a:hover {

            background-color: #22948f;

        }

        .contact_widget li a:hover {

            color: #22948f;

        }

        .contact_widget_2 li a:hover {

            color: #22948f;

        }

        .twitter_widget li a {

            color: #22948f;

        }

        .blog_article .entry-header a:hover {

            color: #22948f;

        }

        .blog_article .entry-footer ul li a:hover {

            color: #22948f;

        }

        .blog_ws .blog_article .button_white:hover {

            background-color: #22948f;

            border-color: #22948f;

        }

        .event .event_title a:hover {

            color: #22948f;

        }

        .boxed_fluid.black_version .our_team_bg .our_team {

            background-color: #22948f;

        }

        .recent_posts .recent_post .recent_post_title a:hover {

            color: #22948f;

        }

        .service .service_activ {

            background-color: #22948f;

        }

        .related_services h3 a:hover {

            color: #22948f;

        }

        .custom-content-reveal span.custom-content-close {

            background-color: #22948f;

        }

        .custom-content-reveal h4 {

            border-top-color: #22948f;

        }

        .custom-content-reveal a {

            color: #22948f;

        }

        .fc-calendar .fc-row > div.fc-content:hover:after{

            color: #22948f;

        }

        .color_scheme select:focus {

            border-color: #22948f;

        }

        .input_button,

        .skills .skill_cover .skill,

        .share_it .socials_2 li a:hover,

        .pricing_table_2 .pt_button,

        .custom-content-reveal span.custom-content-close,

        .service .service_activ,

        .our_team_bg,

        .button_color {

            background-color: #22948f;

        }

        .boxed_fluid.black_version .blog_article .entry-header a:hover,

        .boxed_fluid.black_version .contect_bg .accordion_v2 .accordion-heading.active span,

        .widget ul li a:hover,

        a:hover,

        .blog_article .entry-header a:hover,

        .twitter_widget li a,

        .blog_article .entry-footer ul li a:hover,

        .contact_widget_2 li a:hover,

        .contact_widget li a:hover,

        .accordion-heading.active span,

        .error_404 .error_text span span,

        .header .menu ul li .children li .children li a:hover,

        .header .menu ul li .sub-menu li .sub-menu li a:hover,

        .header .menu ul li .children li:hover a,

        .header .menu ul li .sub-menu li:hover a,

        .event .event_title a:hover,

        .fc-calendar .fc-row > div.fc-content:hover:after,

        .custom-content-reveal a,

        .related_services h3 a:hover,

        .recent_posts .recent_post .recent_post_title a:hover,

        .header .menu ul li .children li a:hover,

        .header .menu ul li .sub-menu li a:hover,

        .portfolio .portfolio_item .item_hover .item_tags li a,

        .tabs .tab-content .tab_title a:hover {

            color: #22948f;

        }

        .header .menu ul li.current_page_item a,

        .header .menu ul li a:hover,

        .header .menu ul li:hover a {

            border-bottom-color: #22948f;

        }

        .tabs .tab_nav li.active a,

        .custom-content-reveal h4,

        .header .menu ul li .children li:hover .children,

        .header .menu ul li .sub-menu li:hover .sub-menu {

            border-top-color: #22948f;

        }

        .page-numbers li a.active,

        .page-numbers li a:hover,

        .filter li a.active,

        .filter li a:hover {

            color: #22948f;

            border-bottom-color: #22948f;

        }

        .blog_ws .blog_article .button_white:hover {

            background-color: #22948f;

            border-color: #22948f;

        }

        .footer .widget ul li {

            color: #22948f;

        }

        #wp-calendar tfoot td a:hover {

            color: #22948f;

        }

        h3 {
  font-size: 24px;
}
.site_content {
  padding: 40px 0px 60px;
  background-image: url(http://ontopoftheworldnews.com/ocala/wp-content/uploads/2015/07/newspaper-bg2.jpg);
  background-position: top right;
  background-repeat: no-repeat;
  background-attachment: fixed;
}
.header {
  border-bottom: #F9AE18 solid 20px;
}
.header .menu ul li.current_page_item a, .header .menu ul li a:hover, .header .menu ul li:hover a {
  border-bottom-color: #f9ae18;
}
.header .menu ul li.current_page_item a, .header .menu ul li a:hover, .header .menu ul li:hover a {
  border-bottom: 8px solid #fddfa3;
}
.header .menu ul li a {
  padding: 18px 15px 28px;
}
.otownewslogo {
  margin-bottom:4%;
}
.input_button, .skills .skill_cover .skill, .share_it .socials_2 li a:hover, .pricing_table_2 .pt_button, .custom-content-reveal span.custom-content-close, .service .service_activ, .our_team_bg, .button_color {
  background: #000;
}
.gray-bg {
  background-image: url(http://ontopoftheworldnews.com/ocala/wp-content/uploads/2015/07/gray-trans80.png);
  padding:20px;
  width:90%;
}
.span6menu {
  float: right;
  min-height: 1px;
  margin-left: 20px;
  margin-top:56px;
}

.path {
  padding: 0px 0px 40px;
  margin-bottom: 0px;
  visibility: collapse;
}
.contact_widget_2 li {
  color: #000;
}
.contact_form p {
  color: #000;
}
.service {
  background: #fddfa3;
  border-bottom: none;
  border: 4px solid #f9ae18;
}
.blog_ws .blog_article .entry-footer {
    visibility: collapse;
}
</style>
    </head>
    <body class="home page page-id-716 page-template-default electra_custom_background">

        <!-- ================================= END BLACK-WHITE VERSION === -->
        <!-- ================================= START CLASS FOR BOXED/FLUID -->

        <div class="boxed_fluid">
           <!-- ================================= START CLASS HEADER -->
            <div class="header">
                <div class="container">
                    <div class="row">
                        <div class="span6">
                            <div class="logo">
                                <a href="http://ontopoftheworldnews.com/ocala">
                                    <div class="otownewslogo"><img src="http://ontopoftheworldnews.com/ocala/wp-content/uploads/2015/07/World-News-Logos-2014_White.png"></div>
                                </a>
                            </div>
                        </div>
                        <div class="span6menu">
                            <div class="menu">
                            <ul id="menu-primary" class="menu">
                                <li id="menu-item-752" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-716 current_page_item menu-item-has-children menu-item-752"><a href="login.php">Log In</a>
                                </li>
                            </ul>   
                            </div> 
                       </div>
                        <div class="clear"></div>
                    </div>
            </div>
      </div>
            <!-- ================================= END CLASS HEADER -->
              <div class="site_content">
                <div class="container">
                <div class="row">
                <div class="span7">
                <div class="gray-bg">
                <h3>Thank you for your business!</h3>
<?php

        if (login_check($mysqli) == true) {
						echo '<p>The World News is processing payment from ' . htmlentities($_SESSION['advertiser']) . ' via PayPal.  The payment will show as WORLDNEWSOC or WORLDNEWSOCALA on your credit card statement.</p>';
						echo '<p>Payment will be shown as withdrawn once completely processed.</p>';
						echo '<p>If you have more than one ad in the next issue, go to <a href="renewals.php">' . htmlentities($_SESSION['advertiser']) . '</a> to submit another payment.</p>';
						echo '<p>Please feel free to contact (352) 387-7466 or <a href="mailto:otownews@otowfl.com">otownews@otowfl.com</a> (Monday-Friday, 8 a.m. to 1 p.m.) with any questions you may have.</p>';
						echo '<p><a href="adv_essentials/logout.php">Log out</a>.</p>';
        } else {
                        echo '<p>Return to <a href="login.php">Log In</a> page.</p>';
                }
?> 
            </div>
            <div class="span5">
            <p></p>
            </div>                
            </div>
                </div>	
                </div>	
      <div class="footer">
   <div class="container">
   <div class="row">

   <div class="span4"></div>
   <div class="span3 offset1">		            <div id="nav_menu-2" class="widget_nav_menu widget"><div class="widget-title">Important Links</div><div class="menu-downloads-container"><ul id="menu-downloads" class="menu"><li id="menu-item-692" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-692"><a href="http://ontopoftheworldnews.com/ocala/electra_services/rates/">Advertising Rates</a></li>
<li id="menu-item-693" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-693"><a href="http://ontopoftheworldnews.com/ocala/electra_services/scheduledeadlines/">Advertising Deadline</a></li>
<li id="menu-item-694" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-694"><a href="http://ontopoftheworldnews.com/ocala/electra_services/inserts/">Inserts</a></li>
<li id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-695"><a href="http://ontopoftheworldnews.com/ocala/electra_services/current-promo/">Current Promo</a></li>
</ul></div></div>		        </div>		        <div class="span3 offset1">		            <div id="electra_contact_widget-2" class="electra_contact_widget "><div class="widget-title">The World News</div>        <ul class="contact_widget">
            <li class="phone">(352) 387-7466</li>
            <li class="fax"></li>
            <li class="mail"><a href="mailto:otownews@otowfl.com">otownews@otowfl.com</a></li>
            <li class="location">8447 SW 99th Street Road<br/>Ocala, FL 34481<br/> <br/> Office Hours: M�F, 8am�1pm </li>
        </ul>
        </div>		        </div>		    </div>		</div>	</div>	




<div class="footer_bottom">		
    <div class="container">
        <div class="row">
            <div class="span6">
                <p>� 2015 On Top of the World Communities, Inc. <span>| All rights reserved.<a href="http://www.teslathemes.com" target="_blank"></a></span>
                </p>
            </div>		        
            <div class="span6"><ul class="socials"></ul></div>		    
            </div>		

    </div>	

</div>
   </div>
</div>
<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?v=3.exp&#038;sensor=false&#038;libraries=places&#038;ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/tesla_framework/static/js/subscription.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://w.sharethis.com/button/buttons.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/bootstrap.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/countdown.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/data.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/imagesloaded.pkgd.min.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/jquery-ui.min.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/jquery.calendario.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/jquery.swipebox.min.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/masonry.pkgd.min.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/modernizr.custom.63321.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/placeholder.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-content/themes/electra/js/options.js?ver=4.3.4'></script>
<script type='text/javascript' src='http://ontopoftheworldnews.com/ocala/wp-includes/js/comment-reply.min.js?ver=4.3.4'></script>
</body>
</html>
