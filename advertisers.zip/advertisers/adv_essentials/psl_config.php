<?php
/**
 * These are the database login details
 */  
define("HOST", "45.40.164.19");     // The host you want to connect to.
define("USER", "ocalaworldnewsob");    // The database username. 
define("PASSWORD", "W0rldN3w5!");    // The database password. 
define("DATABASE", "ocalaworldnewsob");    // The database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!!


?>