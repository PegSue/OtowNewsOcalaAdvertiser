<?php 
include_once dirname(__FILE__)."/db_connect.php";
include_once dirname(__FILE__)."/functions.php";

sec_session_start(); // Our custom secure way of starting a PHP session.
if(login_check($mysqli) == true) {
//if(isset($_POST['userfile'])){
        // Add your protected page content here!
        $uploadfile="";
	$allowed_filetypes = array(".csv"); 
	$allowed_filename ="renewals.csv";
	$max_filesize = 100000; // Maximum filesize in BYTES (currently 1MB).
	$min_filesize = 1;
	$target_path = "../editor_uploads/";  // The place the files will be uploaded to (currently a 'files' directory).
	
//$target_path = $target_path . basename( $_FILES['upload_file']['name']); 

   $filename = $_FILES['userfile']['name']; // Get the name of the file (including file extension).
   $ext = substr($filename, strpos($filename,'.'), strlen($filename)-1); // Get the extension from the filename.
 
   if ($filename <> $allowed_filename) {
      die('The file you attempted to upload is not renewals: '. $filename );        
   }
 
   if(filesize($_FILES['userfile']['tmp_name']) > $max_filesize){
      die('The file you attempted to upload is too large.');
   }  
   if(filesize($_FILES['userfile']['tmp_name']) < $min_filesize){
      die('The file you attempted to upload is too small.');
   } 
          // Check if we can upload to the specified path, if not DIE and inform the user.
   if(!is_writable($target_path)) {
      die('You cannot upload to the specified directory, please CHMOD to 755.');
   } 

      // Check if the filetype is allowed, if not DIE and inform the user.
 if(!in_array($ext,$allowed_filetypes)){
   die('The file you attempted to upload is not allowed: '. $filename );
 }
 
//import the data to renewals and advertiser

 If($query = $mysqli->prepare("Delete from renewals where type='RENEW' or type is null")) {
     $query->execute();
     $file=fopen($_FILES['userfile']['tmp_name'],"r");
     $size = filesize($_FILES['userfile']['tmp_name']);
     $filedate = date("F d Y H:i:s",filemtime($_FILES['userfile']['tmp_name']));
     $rows = 0;
     $rowsimported = 0;

     while (($data = fgetcsv($file,$size,",")) !== FALSE) {
        If ($rows > 0 && isset($data[1])){ 
          If($query = $mysqli->prepare("Insert into renewals(companynumber,code,company,renewby,adbegins,aditem
		    ,size,color,insertions,adprice,specialfee,specialprice,adtotal,location,type)values('$data[0]','$data[1]'
		    ,'$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]','$data[10]'
		    ,'$data[11]','$data[12]','$data[13]','$data[14]')")) {
	    $query->execute();
            ++$rowsimported;
	  } else {// Could not create a prepared statement
            Echo 'Database error: cannot prepare statement at renewals row '. $rows;
            exit();
          }
       }
      ++$rows;	
    }
   --$rows;
   fclose($file); 

   		//DELETE ADVERTISERS where the Advertiser does not have a matching code on type Invoice
	If($query = $mysqli->prepare("Delete from advertiser where code not in(Select code from renewals where type='INVOICE' Group by code) 
	and companynumber not in(1)")) {
	   $query->execute();   
	  } else {// Could not create a prepared statement
            Echo 'Database error: cannot prepare statement delete advertisers';
            exit();
	  }
  
        //new advertisers inserted  	
	If($query = $mysqli->prepare("Insert into advertiser(companynumber,company,code,location) Select r.companynumber,r.company,r.code,r.location from 
	   (Select renewals.companynumber,renewals.company,renewals.code,renewals.location from renewals left join advertiser on advertiser.code = renewals.code
	    where advertiser.code is null group by renewals.companynumber, renewals.company, renewals.code, renewals.location) r")) {
	   $query->execute();   
	  } else {// Could not create a prepared statement
            Echo 'Database error: cannot prepare statement inserted advertisers';
            exit();
	  }

	  //
	//delete login attempts records	
	If($query = $mysqli->prepare("Delete from loginattempts")) {
	   $query->execute();   
	  } else {// Could not create a prepared statement
            Echo 'Database error: cannot prepare statement delete login attempts';
            exit();
	  }

	            
 } else {// Could not create a prepared statement
     Echo "Database error: cannot prepare statement";
     exit();
    }
 //} 
//import the data to advertiser 
/*
   $file=fopen($_FILES['userfile']['tmp_name'],"r");
  $size = filesize($_FILES['userfile']['tmp_name']);
  $rows = 0;
  $rowsimported = 0;
  	$query="Delete from renewals";
	$query = $mysqli->prepare($query);
	$query->execute(); 
   while (($data = fgetcsv($file,$size,",")) !== FALSE) {
      If ($rows > 0 && isset($data[1])){
        $query = "Insert into renewals(companynumber,code,company,renewby,adbegins,aditem,size,color
        ,insertions,adprice,specialfee,specialprice,adtotal,location)values('$data[0]','$data[1]','$data[2]','$data[3]'
        ,'$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]','$data[10]','$data[11]','$data[12]','$data[13]')";
	$query = $mysqli->prepare($query);
	$query->execute();
        ++$rowsimported;   
 	}
     ++$rows;	
  }
   --$rows;
     fclose($file);    
*/
  // Upload the file to your specified path.
  //'View <a href=dirname(__FILE__)."/editor_uploads/renewals.csv" title="Your File"> Advertising Renewals</a>
  if(move_uploaded_file($_FILES['userfile']['tmp_name'],$target_path . $filename)) {
  //  $uploadfile = ' created ' .$filedate . ' where ' .$rowsimported .
  // ' row(s) imported or updated during upload!';// It worked.

  // echo 'View <a href="'. $target_path . $filename .'" title="renewals">Advertising Renewals</a> file created ' .$filedate . ' where '.$rowsimported .' row(s) imported or updated during upload!';
   }
    else {
  //  echo' There was an error during the file upload.  Please try again.'; // It failed }
    }
 

//}
 header("Location: ../editor_uploads.php"); 
} else { 
        echo 'You are not authorized to access this page, please login.';
}

?>

