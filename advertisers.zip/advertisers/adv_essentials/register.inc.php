<?php
include_once dirname(__FILE__)."/db_connect.php";

$error_msg = "";

if (isset($_POST['code'], $_POST['p'])) {
    // Sanitize and validate the data passed in
   $code = filter_input(INPUT_POST, 'code', FILTER_SANITIZE_STRING);
/*   
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Not a valid email
        $error_msg .= '<p class="error">The email address you entered is not valid</p>';
    }
 */   
    $password = filter_input(INPUT_POST, 'p', FILTER_SANITIZE_STRING);
    if (strlen($password) != 128) {
        // The hashed pwd should be 128 characters long.
        // If it's not, something really odd has happened
        $error_msg .= '<p class="error">Invalid password configuration.</p>';
    }

    // Username validity and password validity have been checked client side.
    // This should should be adequate as nobody gains any advantage from
    // breaking these rules.
    //

    $prep_stmt = "SELECT id FROM advertiser WHERE code = ? and password IS NOT NULL LIMIT 1";
    $stmt = $mysqli->prepare($prep_stmt);

    if ($stmt) {
        $stmt->bind_param('s', $code);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows == 1) {
            // A user with this code already exists
            $error_msg .= '<p class="error">Registration for Advertiser Code exists.</p><p>Return to <a href="login.php">Log In</a> page</p>';
        } else {
        $stmt->close();
        $prep_stmt = "SELECT id FROM advertiser WHERE code = ? LIMIT 1";
   	$stmt = $mysqli->prepare($prep_stmt); 
   		if ($stmt) {
   	      	$stmt->bind_param('s', $code);
       	     	$stmt->execute();
	     	$stmt->store_result();
	     	if ($stmt->num_rows == 0) {
           		// code does not exist
           		$error_msg .= '<p class="error">Advertiser Code <u>'.$code.'</u> does not exist.</p><p>Return to <a href="login.php">Log In</a> page</p>';
       	 		} 

	     	} else {
    			$error_msg .= '<p class="error">Prepared Statement Error Line 41.</p>';}


   		}
    	} else {
        $error_msg .= '<p class="error">Prepared Statement Error Line 28.</p>';
    	}

    // TODO: 
    // We'll also have to account for the situation where the user doesn't have
    // rights to do registration, by checking what type of user is attempting to
    // perform the operation.

    if (empty($error_msg)) {
        // Create a random salt - this is for > php version 5.2 as of 6/22/16 world news uses 5.2
        //$random_salt = hash('sha512', uniqid(openssl_random_pseudo_bytes(16), TRUE));
		$bytes = '';
		$fp = fopen('/dev/urandom','rb');
		$bytes = uniqid(fread($fp,16), True);
		fclose($fp);
		$random_salt = hash('sha512', $bytes);
		

        // Create salted password 
        $password = hash('sha512', $password . $random_salt);

        // Update and register the Advertersier
        if ($update_stmt = $mysqli->prepare("UPDATE advertiser SET password = ?, salt = ? WHERE code='$code'")) {
            $update_stmt->bind_param('ss', $password, $random_salt);
            // Execute the prepared query.
            if (! $update_stmt->execute()) {
                header('Location: error.php?err=Registration failure: UPDATE');
                exit();
            }
        }
 
        header('Location: success.html');
        exit();
        }
}
?> 
      
 
