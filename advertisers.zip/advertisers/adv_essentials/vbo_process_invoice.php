<?php 
include_once dirname(__FILE__)."/db_connect.php";

//import the data to renewals and advertiser
 //If($query = $mysqli->prepare("Delete from renewals where type='INVOICE'")) {

     $file = fopen("../editor_uploads/invoice.csv","r");
     $size = filesize("../editor_uploads/invoice.csv");
     //$filedate = date("F d Y H:i:s",filemtime($_FILES['userfile']['tmp_name']));
	 
     $rows = 0;
	 
     while (($data = fgetcsv($file,$size,",")) !== FALSE) {
		If ($rows > 0 && isset($data[1])){ 

		   If($query = $mysqli->prepare("Delete from renewals where companynumber=$data[0] 
			and aditem='$data[5]' and location='$data[13]' and type='INVOICE'")) {
			$query->execute();
			} else {// Could not create a prepared statement
			Echo 'Database error: cannot prepare delete invoice statement';
			exit();
			}

          If($query = $mysqli->prepare("Insert into renewals(companynumber,code,company,renewby,adbegins,aditem
		    ,size,color,insertions,adprice,specialfee,specialprice,adtotal,location,type)values('$data[0]','$data[1]'
		    ,'$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]','$data[10]'
		    ,'$data[11]','$data[12]','$data[13]','$data[14]')")) {
	     $query->execute();
          } else {// Could not create a prepared statement
            Echo 'Database error: cannot prepare statement at renewals row '. $rows;
            exit();
          }
       }
      ++$rows;	
    }
   --$rows;
   fclose($file);
   	  //
	//delete login attempts records	
	If($query = $mysqli->prepare("Delete from loginattempts")) {
	   $query->execute();   
	  } else {// Could not create a prepared statement
            Echo 'Database error: cannot prepare statement delete login attempts';
            exit();
	  }
    //new advertiser inserted  	
	If($query = $mysqli->prepare("Insert into advertiser(companynumber,company,code,location) Select r.companynumber,r.company,r.code,r.location from 
	   (Select renewals.companynumber,renewals.company,renewals.code,renewals.location from renewals left join advertiser on advertiser.code = renewals.code
	    where advertiser.code is null group by renewals.companynumber, renewals.company, renewals.code, renewals.location) r")) {
	   $query->execute();   
	  } else {// Could not create a prepared statement
            Echo 'Database error: cannot prepare statement inserted advertisers';
            exit();
	  }

	            
  // Upload the file to your specified path.
  //'View <a href=dirname(__FILE__)."/editor_uploads/renewals.csv" title="Your File"> Advertising Renewals</a>
  if(move_uploaded_file($_FILES['userfile']['tmp_name'],$target_path . $filename)) {
  //  $uploadfile = ' created ' .$filedate . ' where ' .$rowsimported .
  // ' row(s) imported or updated during upload!';// It worked.

  // echo 'View <a href="'. $target_path . $filename .'" title="renewals">Advertising Renewals</a> file created ' .$filedate . ' where '.$rowsimported .' row(s) imported or updated during upload!';
   }
    else {
  //  echo' There was an error during the file upload.  Please try again.'; // It failed }
    }


?>

