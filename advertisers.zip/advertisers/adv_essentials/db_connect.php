<?php
//Global $mysqli;
include_once dirname(__FILE__)."/psl_config.php";   // As functions.php is not included
$mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);
?>